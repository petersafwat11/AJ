import React from "react";
import "./Middle.scss";
const Middle = ({ children }) => {
  return <div className="middle">{children}</div>;
};

export default Middle;
