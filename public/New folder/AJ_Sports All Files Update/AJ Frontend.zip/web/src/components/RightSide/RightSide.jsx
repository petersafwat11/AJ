import React from "react";
import "./RightSide.scss";
const RightSide = ({ children }) => {
  return <div className="right">{children}</div>;
};

export default RightSide;
