import "./App.scss";
// import StaticsTable from "./screen/StaticsTable/StaticsTable";
// import DeskTopFive from "./screen/DeskTopFive/DeskTopFive";
// import DeskTopThree from "./screen/DeskTopThree/DeskTopThree";
// import DeskTopTwo from "./screen/DeskTopTwo/DeskTopTwo";

// import DeskTopOne from "./screen/DeskTopOne/DeskTopOne";
// import SchudleTable from "./screen/SchudleTable/SchudleTable";

// import DonateForm from "./screen/DonateForm/DonateForm";
// import GiveAwayForm from "./screen/GiveAwayForm/GiveAwayForm";
// import ContactUs from "./screen/ContactUs/ContactUs";
// import DeskTopFour from "./screen/DeskTopFour/DeskTopFour";

import Routess from "./Routes";
function App() {
  return (
    <>
      <div className="overallbackgroud">
        {/* <DeskTopOne /> */}
        {/* <DeskTopTwo /> */}
        {/* <DeskTopThree /> */}
        {/* <DeskTopFour /> */}
        {/* <DeskTopFive /> */}
        {/* <DonateForm /> */}
        {/* <GiveAwayForm /> */}
        {/* <ContactUs /> */}
        {/* <SchudleTable /> */}

        {/* <StaticsTable /> */}

        <Routess />
      </div>
    </>
  );
}

export default App;
