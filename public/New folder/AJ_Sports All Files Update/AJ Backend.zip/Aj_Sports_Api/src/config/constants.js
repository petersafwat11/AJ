module.exports = {
  roles: ["User", "Admin"],
};
