const active_session_count = 5000;
const maximum_allowed_users = 5000;

module.exports = {
  active_session_count,
  maximum_allowed_users,
};
