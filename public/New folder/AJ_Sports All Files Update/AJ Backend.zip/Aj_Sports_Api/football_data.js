const footballData = [
  {
    name: "Ligue 1",
    country: "France",
  },
  {
    name: "Serie A",
    country: "Italy",
  },
  {
    name: "Bundesliga",
    country: "Germany",
  },
  {
    name: "La Liga",
    country: "Spain",
  },
  {
    name: "Premier League",
    country: "England",
  },
  {
    name: "UEFA Europa League",
    country: "World",
  },
  {
    name: "UEFA Champions League",
    country: "World",
  },
];

module.exports = footballData;
